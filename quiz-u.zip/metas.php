<?php
	$metas = array(
		"mal" => array(
			"title" => "Adivina Juan",
			"description" => "¡Nooooooooooo! ¡Nooooooooooo! ¡Corre antes de que el Piojo diga que fuiste tú el culpable de todo!",
			"image" => "images/resultados-1.jpg" 
		),
		"maso" => array(
			"title" => "Adivina Juan",
			"description" => "Pues mira, peor es nada. Al menos Herrera no tendrá pretexto para querer correrte o echarte la culpa",
			"image" => "images/resultados-2.jpg" 
		),
		"bien" => array(
			"title" => "Adivina Juan",
			"description" => "¡HÉROE! ¿Gudiño qué? ¡Tú eres el mero mero! ¡Vámonos al Ángel!",
			"image" => "images/resultados-3.jpg" 
		)
	);